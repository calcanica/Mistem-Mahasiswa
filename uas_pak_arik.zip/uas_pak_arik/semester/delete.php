<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/db.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: list.php');
    exit();
}
$id = (int)$_GET['id'];
$conn->query("DELETE FROM semester WHERE id_semester=$id");
header('Location: list.php');
exit(); 