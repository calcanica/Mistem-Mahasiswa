<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/db.php';

$success = $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $conn->real_escape_string($_POST['nama_semester']);
    if ($nama) {
        $cek = $conn->query("SELECT * FROM semester WHERE nama_semester='$nama'");
        if ($cek && $cek->num_rows > 0) {
            $error = 'Semester sudah ada!';
        } else {
            if ($conn->query("INSERT INTO semester (nama_semester) VALUES ('$nama')")) {
                header('Location: list.php');
                exit();
            } else {
                $error = 'Gagal menambah semester!';
            }
        }
    } else {
        $error = 'Nama semester wajib diisi!';
    }
}
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Tambah Semester</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="../AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/dist/css/adminlte.min.css">
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
  <!-- Navbar -->
  <nav class="app-header navbar navbar-expand bg-body">
    <div class="container-fluid">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button">
            <i class="fas fa-bars"></i>
          </a>
        </li>
        <li class="nav-item d-none d-md-block"><a href="list.php" class="nav-link">Data Semester</a></li>
      </ul>
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </li>
      </ul>
    </div>
  </nav>
  <!-- Sidebar -->
  <aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
    <div class="sidebar-brand">
      <a href="../index.php" class="brand-link">
        <img src="../AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/src/assets/img/AdminLTELogo.png" alt="Logo" class="brand-image opacity-75 shadow" />
        <span class="brand-text fw-light">Sistem Mahasiswa</span>
      </a>
    </div>
    <div class="sidebar-wrapper">
      <nav class="mt-2">
        <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu" data-accordion="false">
          <li class="nav-item">
            <a href="../index.php" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item menu-open">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-calendar-alt"></i>
              <p>Data Semester</p>
            </a>
          </li>
        </ul>
      </nav>
    </div>
  </aside>
  <!-- Content Wrapper -->
  <main class="app-main">
    <div class="app-content p-4">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Tambah Semester</h1>
          </div>
          <div class="col-sm-6 text-end">
            <a href="list.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Kembali</a>
          </div>
        </div>
        <div class="row justify-content-center">
          <div class="col-md-6">
            <div class="card card-primary">
              <div class="card-header"><h3 class="card-title">Form Tambah Semester</h3></div>
              <form method="post" autocomplete="off">
                <div class="card-body">
                  <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                  <?php endif; ?>
                  <div class="mb-3">
                    <label class="form-label">Nama Semester</label>
                    <input type="text" name="nama_semester" class="form-control" required>
                  </div>
                </div>
                <div class="card-footer text-end">
                  <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
</div>
<script src="../AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/plugins/jquery/jquery.min.js"></script>
<script src="../AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/dist/js/adminlte.min.js"></script>
</body>
</html> 