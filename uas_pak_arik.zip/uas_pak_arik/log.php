<a class="nav-link" data-lte-toggle="sidebar" href="#" role="button" style="padding-top:2px">
  <svg width="24" height="24" viewBox="0 0 24 24" fill="#6c757d" xmlns="http://www.w3.org/2000/svg">
    <rect y="4" width="24" height="2" rx="1"/>
    <rect y="11" width="24" height="2" rx="1"/>
    <rect y="18" width="24" height="2" rx="1"/>
  </svg>
</a> 