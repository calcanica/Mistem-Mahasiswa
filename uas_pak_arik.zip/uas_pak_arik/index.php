<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/config/db.php';

date_default_timezone_set('Asia/Jakarta');
$jumlah_mahasiswa = $conn->query('SELECT COUNT(*) as total FROM mahasiswa')->fetch_assoc()['total'];
$jumlah_jurusan = $conn->query('SELECT COUNT(*) as total FROM jurusan')->fetch_assoc()['total'];
$jumlah_semester = $conn->query('SELECT COUNT(*) as total FROM semester')->fetch_assoc()['total'];
$nama = $_SESSION['nama_pengguna'];
$username = $_SESSION['username'];

// Data untuk Pie Chart: Komposisi mahasiswa per jurusan
$pie_labels = [];
$pie_data = [];
$q = $conn->query('SELECT j.nama_jurusan, COUNT(m.id_mahasiswa) as total FROM jurusan j LEFT JOIN mahasiswa m ON m.id_jurusan=j.id_jurusan GROUP BY j.id_jurusan');
while($row = $q->fetch_assoc()) {
    $pie_labels[] = $row['nama_jurusan'];
    $pie_data[] = (int)$row['total'];
}
// Data mahasiswa terbaru
$recent = $conn->query('SELECT * FROM mahasiswa ORDER BY id_mahasiswa DESC LIMIT 5');
// Data untuk Bar Chart: Mahasiswa per semester
$bar_labels = [];
$bar_data = [];
$q2 = $conn->query('SELECT s.nama_semester, COUNT(m.id_mahasiswa) as total FROM semester s LEFT JOIN mahasiswa m ON m.id_semester=s.id_semester GROUP BY s.id_semester');
while($row = $q2->fetch_assoc()) {
    $bar_labels[] = $row['nama_semester'];
    $bar_data[] = (int)$row['total'];
}
// Data untuk Progress Bar: Persentase mahasiswa per jurusan
$progress = [];
$total_mhs = $jumlah_mahasiswa > 0 ? $jumlah_mahasiswa : 1;
$q3 = $conn->query('SELECT j.nama_jurusan, COUNT(m.id_mahasiswa) as total FROM jurusan j LEFT JOIN mahasiswa m ON m.id_jurusan=j.id_jurusan GROUP BY j.id_jurusan');
while($row = $q3->fetch_assoc()) {
    $progress[] = [
        'jurusan' => $row['nama_jurusan'],
        'total' => (int)$row['total'],
        'persen' => round($row['total']/$total_mhs*100)
    ];
}
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Dashboard | Sistem Mahasiswa</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/dist/css/adminlte.min.css">
  <style>
    .custom-box {
      border-radius: 8px;
      min-height: 120px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
      position: relative;
      overflow: hidden;
      margin-bottom: 16px;
      transition: box-shadow 0.2s;
    }
    .custom-box .inner h3 {
      font-size: 2.5rem;
      font-weight: bold;
      color: #1877f2;
      margin-bottom: 0.5rem;
    }
    .custom-box .inner p {
      font-size: 1.1rem;
      color: #fff;
      margin-bottom: 0;
    }
    .custom-box .icon {
      opacity: 0.15;
      position: absolute;
      right: 20px;
      bottom: 10px;
      font-size: 70px;
      color: #fff;
    }
    .custom-blue { background: #1877f2; }
    .custom-green { background: #218838; }
    .custom-yellow { background: #ffc107; }
    .custom-red { background: #dc3545; }
    .custom-yellow .inner h3, .custom-yellow .inner p, .custom-yellow .small-box-footer { color: #212529 !important; }
    .custom-box .small-box-footer {
      background: rgba(0,0,0,0.04);
      color: #fff;
      text-align: left;
      padding: 8px 16px;
      font-weight: 500;
      border-radius: 0 0 8px 8px;
      position: absolute;
      bottom: 0; left: 0; width: 100%;
      text-decoration: none;
    }
    .custom-yellow .small-box-footer { color: #212529 !important; }
    .custom-box:hover { box-shadow: 0 4px 16px rgba(0,0,0,0.10); }
  </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
  <!-- Navbar -->
  <nav class="app-header navbar navbar-expand bg-body">
    <div class="container-fluid">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button" style="padding-top:2px">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="#6c757d" xmlns="http://www.w3.org/2000/svg">
              <rect y="4" width="24" height="2" rx="1"/>
              <rect y="11" width="24" height="2" rx="1"/>
              <rect y="18" width="24" height="2" rx="1"/>
            </svg>
          </a>
        </li>
        <li class="nav-item d-none d-md-block"><a href="#" class="nav-link">Home</a></li>
      </ul>
      <ul class="navbar-nav ms-auto">
        <li class="nav-item d-flex align-items-center">
          <img src="AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/src/assets/img/user1-128x128.jpg" class="rounded-circle shadow me-2" style="width:32px; height:32px; object-fit:cover;">
          <span class="fw-semibold me-2"><?php echo $_SESSION['nama_pengguna']; ?></span>
          <a href="logout.php" class="btn btn-danger btn-sm"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </li>
      </ul>
    </div>
  </nav>
  <!-- Sidebar -->
  <aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
    <div class="sidebar-brand">
      <a href="index.php" class="brand-link">
        <img src="AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/src/assets/img/AdminLTELogo.png" alt="Logo" class="brand-image opacity-75 shadow" />
        <span class="brand-text fw-light">Sistem Mahasiswa</span>
      </a>
    </div>
    <div class="sidebar-wrapper">
      <nav class="mt-2">
        <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu" data-accordion="false">
          <li class="nav-item menu-open">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="mahasiswa/list.php" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p>Data Mahasiswa</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="jurusan/list.php" class="nav-link">
              <i class="nav-icon fas fa-building"></i>
              <p>Data Jurusan</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="semester/list.php" class="nav-link">
              <i class="nav-icon fas fa-calendar-alt"></i>
              <p>Data Semester</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="log/list.php" class="nav-link">
              <i class="nav-icon fas fa-history"></i>
              <p>Log Aktivitas</p>
            </a>
          </li>
        </ul>
      </nav>
    </div>
  </aside>
  <!-- Content Wrapper -->
  <main class="app-main">
    <div class="app-content p-4">
      <div class="container-fluid">
        <div class="alert alert-info mb-4"><i class="fas fa-info-circle"></i> Database sudah di-backup secara otomatis setiap hari.</div>
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-end">
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-3 col-6">
            <div class="small-box text-bg-primary">
              <div class="inner">
                <h3><?php echo $jumlah_mahasiswa; ?></h3>
                <p>Mahasiswa</p>
              </div>
              <svg class="small-box-icon" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5s-3 1.34-3 3 1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05C15.64 13.36 17 14.28 17 15.5V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/>
              </svg>
              <a href="mahasiswa/list.php" class="small-box-footer link-light link-underline-opacity-0 link-underline-opacity-50-hover">More info <i class="bi bi-link-45deg"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-6">
            <div class="small-box text-bg-success">
              <div class="inner">
                <h3><?php echo $jumlah_jurusan; ?></h3>
                <p>Jurusan</p>
              </div>
              <svg class="small-box-icon" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <path d="M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 8h14v-2H7v2zm0-4h14v-2H7v2zm0-6v2h14V7H7z"/>
              </svg>
              <a href="jurusan/list.php" class="small-box-footer link-light link-underline-opacity-0 link-underline-opacity-50-hover">More info <i class="bi bi-link-45deg"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-6">
            <div class="small-box text-bg-warning">
              <div class="inner text-white">
                <h3><?php echo $jumlah_semester; ?></h3>
                <p>Semester</p>
              </div>
              <svg class="small-box-icon" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zm-7-3c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4z"/>
              </svg>
              <a href="semester/list.php" class="small-box-footer link-light link-underline-opacity-0 link-underline-opacity-50-hover">More info <i class="bi bi-link-45deg"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-6">
            <div class="small-box text-bg-danger">
              <div class="inner">
                <h3>Log</h3>
                <p>Log Aktivitas</p>
              </div>
              <svg class="small-box-icon" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <path d="M12 8V4l8 8-8 8v-4.1C7.1 15.9 4.5 17.5 2 20c1-5 4-8.5 10-12z"/>
              </svg>
              <a href="log/list.php" class="small-box-footer link-light link-underline-opacity-0 link-underline-opacity-50-hover">More info <i class="bi bi-link-45deg"></i></a>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-6">
            <div class="card mb-4">
              <div class="card-header border-0">
                <h3 class="card-title">Komposisi Mahasiswa per Jurusan</h3>
              </div>
              <div class="card-body">
                <div id="pie-chart"></div>
                <hr>
                <h6 class="mb-3">Persentase Mahasiswa per Jurusan</h6>
                <?php foreach($progress as $p): ?>
                  <div class="mb-2">
                    <span><?php echo $p['jurusan']; ?> (<?php echo $p['total']; ?>)</span>
                    <div class="progress">
                      <div class="progress-bar bg-info" style="width: <?php echo $p['persen']; ?>%"> <?php echo $p['persen']; ?>% </div>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
            </div>
            <!-- Log Aktivitas Section dipindah ke sini -->
            <div class="card card-danger mb-4" id="log-aktivitas">
              <div class="card-header">
                <h3 class="card-title"><i class="fas fa-history me-2"></i>Log Aktivitas Terakhir</h3>
              </div>
              <div class="card-body p-0" style="overflow-y:auto; max-height:220px;">
                <table class="table table-striped mb-0">
                  <thead>
                    <tr>
                      <th>Waktu</th>
                      <th>User</th>
                      <th>Aksi</th>
                      <th>Tabel</th>
                      <th>Deskripsi</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $log = $conn->query('SELECT l.*, u.nama_pengguna FROM log_aktivitas l LEFT JOIN users u ON l.id_user=u.id_user ORDER BY l.waktu DESC LIMIT 3');
                    while($l = $log->fetch_assoc()): ?>
                    <tr>
                      <td><?php echo date('d/m/Y H:i', strtotime($l['waktu'])); ?></td>
                      <td><?php echo htmlspecialchars($l['nama_pengguna'] ?? '-'); ?></td>
                      <td><span class="badge bg-<?php echo $l['aksi']==='INSERT'?'success':($l['aksi']==='UPDATE'?'warning':'danger'); ?>"><?php echo $l['aksi']; ?></span></td>
                      <td><?php echo htmlspecialchars($l['tabel']); ?></td>
                      <td><?php echo htmlspecialchars($l['deskripsi']); ?></td>
                    </tr>
                    <?php endwhile; ?>
                  </tbody>
                </table>
              </div>
              <div class="card-footer text-center p-2">
                <a href="log/list.php" class="btn btn-outline-light btn-sm"><i class="fas fa-list"></i> Lihat Semua</a>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="card mb-4">
              <div class="card-header border-0">
                <h3 class="card-title">Mahasiswa Terbaru</h3>
              </div>
              <div class="card-body p-0">
                <table class="table table-striped mb-0">
                  <thead>
                    <tr>
                      <th>Nama</th>
                      <th>NIM</th>
                      <th>Jurusan</th>
                      <th>Semester</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $recent2 = $conn->query('SELECT m.*, j.nama_jurusan, s.nama_semester FROM mahasiswa m JOIN jurusan j ON m.id_jurusan=j.id_jurusan JOIN semester s ON m.id_semester=s.id_semester ORDER BY m.id_mahasiswa DESC LIMIT 5');
                    while($m = $recent2->fetch_assoc()): ?>
                    <tr>
                      <td><?php echo htmlspecialchars($m['nama']); ?></td>
                      <td><?php echo htmlspecialchars($m['nim']); ?></td>
                      <td><?php echo htmlspecialchars($m['nama_jurusan']); ?></td>
                      <td><?php echo htmlspecialchars($m['nama_semester']); ?></td>
                    </tr>
                    <?php endwhile; ?>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="card mb-4">
              <div class="card-header border-0">
                <h3 class="card-title">Statistik Data</h3>
              </div>
              <div class="card-body">
                <div class="row">
                  <div class="col-md-6">
                    <h6>Mahasiswa per Jurusan</h6>
                    <table class="table table-sm table-bordered mb-3">
                      <thead><tr><th>Jurusan</th><th>Jumlah</th></tr></thead>
                      <tbody>
                        <?php $q = $conn->query('SELECT j.nama_jurusan, COUNT(m.id_mahasiswa) as total FROM jurusan j LEFT JOIN mahasiswa m ON m.id_jurusan=j.id_jurusan GROUP BY j.id_jurusan');
                        while($row = $q->fetch_assoc()): ?>
                        <tr><td><?php echo htmlspecialchars($row['nama_jurusan']); ?></td><td><?php echo $row['total']; ?></td></tr>
                        <?php endwhile; ?>
                      </tbody>
                    </table>
                  </div>
                  <div class="col-md-6">
                    <h6>Mahasiswa per Semester</h6>
                    <table class="table table-sm table-bordered mb-0">
                      <thead><tr><th>Semester</th><th>Jumlah</th></tr></thead>
                      <tbody>
                        <?php $q = $conn->query('SELECT s.nama_semester, COUNT(m.id_mahasiswa) as total FROM semester s LEFT JOIN mahasiswa m ON m.id_semester=s.id_semester GROUP BY s.id_semester');
                        while($row = $q->fetch_assoc()): ?>
                        <tr><td><?php echo htmlspecialchars($row['nama_semester']); ?></td><td><?php echo $row['total']; ?></td></tr>
                        <?php endwhile; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            <div class="card mb-4">
              <div class="card-header border-0">
                <h3 class="card-title">Profil Pengguna</h3>
              </div>
              <div class="card-body text-center">
                <img src="AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/src/assets/img/user1-128x128.jpg" class="img-circle mb-2" style="width:80px;">
                <h5 class="mb-0"><?php echo $nama; ?></h5>
                <small class="text-muted"><?php echo $username; ?></small>
                <hr>
                <span class="badge bg-info">Admin</span>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Selamat datang, <?php echo $nama; ?>!</h3>
              </div>
              <div class="card-body">
                <p>Gunakan menu di samping untuk mengelola data mahasiswa.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
</div>
<script src="AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/plugins/jquery/jquery.min.js"></script>
<script src="AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/apexcharts@3.37.1/dist/apexcharts.min.js"></script>
<script src="AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/dist/js/adminlte.min.js"></script>
<script>
// Pie Chart Komposisi Mahasiswa per Jurusan
var options = {
  series: <?php echo json_encode($pie_data); ?>,
  chart: {
    type: 'donut',
    height: 300
  },
  labels: <?php echo json_encode($pie_labels); ?>,
  colors: ['#0d6efd', '#20c997', '#ffc107', '#d63384', '#6f42c1', '#adb5bd'],
  legend: { position: 'bottom' },
  dataLabels: { enabled: true },
};
var chart = new ApexCharts(document.querySelector("#pie-chart"), options);
chart.render();
// Bar Chart Mahasiswa per Semester
var barOptions = {
  series: [{
    name: 'Mahasiswa',
    data: <?php echo json_encode($bar_data); ?>
  }],
  chart: {
    type: 'bar',
    height: 300
  },
  xaxis: {
    categories: <?php echo json_encode($bar_labels); ?>
  },
  colors: ['#0d6efd'],
  dataLabels: { enabled: true },
};
var barChart = new ApexCharts(document.querySelector("#bar-chart"), barOptions);
barChart.render();
</script>
</body>
</html>