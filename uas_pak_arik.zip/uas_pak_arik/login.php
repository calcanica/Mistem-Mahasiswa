<?php
require_once __DIR__ . '/config/db.php';
session_start();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $conn->real_escape_string($_POST['username']);
    $password = hash('sha256', $_POST['password']);
    $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = $conn->query($sql);
    if ($result && $result->num_rows === 1) {
        $user = $result->fetch_assoc();
        $_SESSION['user_id'] = $user['id_user'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['nama_pengguna'] = $user['nama_pengguna'];
        header('Location: index.php');
        exit();
    } else {
        $error = 'Username atau password salah!';
    }
}
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Login | Kelompok 7</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/dist/css/adminlte.min.css">
  <style>
    body { background: #f4f6f9; }
  </style>
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo mb-3">
    <img src="AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/src/assets/img/AdminLTELogo.png" alt="Logo" style="width:70px;">
    <br>
    <b>Sistem</b> Mahasiswa
  </div>
  <div class="mb-2 text-center text-secondary fw-bold" style="font-size:1.2rem; letter-spacing:1px;">Kelompok 7</div>
  <div class="card card-outline card-primary">
    <div class="card-body login-card-body">
      <p class="login-box-msg">Login untuk masuk ke sistem</p>
      <?php if ($error): ?>
        <div class="alert alert-danger py-2"><?php echo $error; ?></div>
      <?php endif; ?>
      <form action="" method="post" autocomplete="off">
        <div class="input-group mb-3">
          <input type="text" name="username" class="form-control" placeholder="Username" required autofocus>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" name="password" class="form-control" placeholder="Password" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <button type="submit" class="btn btn-primary btn-block">Login</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
<script src="AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/plugins/jquery/jquery.min.js"></script>
<script src="AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/dist/js/adminlte.min.js"></script>
</body>
</html> 