<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/db.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: list.php');
    exit();
}
$id = (int)$_GET['id'];
// Ambil data untuk log
$row = $conn->query("SELECT nama, nim FROM mahasiswa WHERE id_mahasiswa=$id")->fetch_assoc();
$nama = $row ? $row['nama'] : '';
$nim = $row ? $row['nim'] : '';
$conn->query("DELETE FROM mahasiswa WHERE id_mahasiswa=$id");
// Logging aktivitas
$id_user = $_SESSION['user_id'];
$desk = "Hapus mahasiswa: $nama ($nim)";
$conn->query("INSERT INTO log_aktivitas (id_user, aksi, tabel, deskripsi, waktu) VALUES ($id_user, 'DELETE', 'mahasiswa', '$desk', NOW())");
header('Location: list.php?hapus=1');
exit(); 