<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../config/db.php';

$sql = 'SELECT l.*, u.nama_pengguna FROM log_aktivitas l LEFT JOIN users u ON l.id_user=u.id_user ORDER BY l.waktu DESC';
$result = $conn->query($sql);
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Log Aktivitas</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="../AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/dist/css/adminlte.min.css">
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
  <!-- Navbar -->
  <nav class="app-header navbar navbar-expand bg-body">
    <div class="container-fluid">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button" style="padding-top:2px">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="#6c757d" xmlns="http://www.w3.org/2000/svg">
              <rect y="4" width="24" height="2" rx="1"/>
              <rect y="11" width="24" height="2" rx="1"/>
              <rect y="18" width="24" height="2" rx="1"/>
            </svg>
          </a>
        </li>
        <li class="nav-item d-none d-md-block">
          <span class="nav-link fw-bold">Log Aktivitas</span>
        </li>
      </ul>
      <ul class="navbar-nav ms-auto">
        <li class="nav-item d-flex align-items-center">
          <img src="../AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/src/assets/img/user1-128x128.jpg" class="rounded-circle shadow me-2" style="width:32px; height:32px; object-fit:cover;">
          <span class="fw-semibold"><?php echo $_SESSION['nama_pengguna']; ?></span>
        </li>
      </ul>
    </div>
  </nav>
  <!-- Sidebar -->
  <aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
    <div class="sidebar-brand">
      <a href="../index.php" class="brand-link">
        <img src="../AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/src/assets/img/AdminLTELogo.png" alt="Logo" class="brand-image opacity-75 shadow" />
        <span class="brand-text fw-light">Sistem Mahasiswa</span>
      </a>
    </div>
    <div class="sidebar-wrapper">
      <nav class="mt-2">
        <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu" data-accordion="false">
          <li class="nav-item">
            <a href="../index.php" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="../mahasiswa/list.php" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p>Data Mahasiswa</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="../jurusan/list.php" class="nav-link">
              <i class="nav-icon fas fa-building"></i>
              <p>Data Jurusan</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="../semester/list.php" class="nav-link">
              <i class="nav-icon fas fa-calendar-alt"></i>
              <p>Data Semester</p>
            </a>
          </li>
          <li class="nav-item menu-open">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-history"></i>
              <p>Log Aktivitas</p>
            </a>
          </li>
        </ul>
      </nav>
    </div>
  </aside>
  <!-- Content Wrapper -->
  <main class="app-main">
    <div class="app-content p-4">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Log Aktivitas</h1>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-bordered table-striped">
                    <thead class="table-dark">
                      <tr>
                        <th>No</th>
                        <th>Waktu</th>
                        <th>User</th>
                        <th>Aksi</th>
                        <th>Tabel</th>
                        <th>Deskripsi</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $no=1; while($row = $result->fetch_assoc()): ?>
                      <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo date('d/m/Y H:i', strtotime($row['waktu'])); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_pengguna'] ?? '-'); ?></td>
                        <td><span class="badge bg-<?php echo $row['aksi']==='INSERT'?'success':($row['aksi']==='UPDATE'?'warning':'danger'); ?>"><?php echo $row['aksi']; ?></span></td>
                        <td><?php echo htmlspecialchars($row['tabel']); ?></td>
                        <td><?php echo htmlspecialchars($row['deskripsi']); ?></td>
                      </tr>
                      <?php endwhile; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
</div>
<script src="../AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/plugins/jquery/jquery.min.js"></script>
<script src="../AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../AdminLTE-4.0.0-beta3/AdminLTE-4.0.0-beta3/dist/js/adminlte.min.js"></script>
</body>
</html> 